# flame-annotations > 2023-11-19 12:44am
https://universe.roboflow.com/wildfiredetection/flame-annotations

Provided by a Roboflow user
License: CC BY 4.0

